package hotel.checkout;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import hotel.credit.CreditAuthorizer;
import hotel.credit.CreditCard;
import hotel.credit.CreditCardHelper;
import hotel.credit.CreditCardType;
import hotel.entities.Hotel;


@ExtendWith(MockitoExtension.class)
class TestCheckout {
	CreditCardType cardType = CreditCardType.VISA;
	int number;
	int ccv;
	int roomId = 101;
	
	@Mock CreditCard mockCredCard;
	@Mock CreditCardHelper creditCardHelper;
	@Mock CreditAuthorizer creditAuthorizer;
	//@Mock Booking booking;
	//@Mock State state;
	@Mock Hotel mockHotel;
	@Mock CheckoutUI checkoutUI;
	
	@InjectMocks CheckoutCTL checkoutCtl = new CheckoutCTL(mockHotel);
	
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCreditStateAsCredit() { //working
		Executable e = () ->  checkoutCtl.creditDetailsEntered(cardType, number, ccv);
		Throwable t = assertThrows(RuntimeException.class, e);
		assertEquals("CheckoutCTL: creditDetailsEntered : bad state : ROOM", t.getMessage());
	}
	
	@Test
	void testCreditDetailsEntered() { //NOT working
		//(CheckoutCTL.class, "CREDIT", state);
		checkoutCtl.roomId = roomId;
		checkoutCtl.state = CheckoutCTL.State.CREDIT;
		
		when(creditCardHelper.makeCreditCard(any(), anyInt(), anyInt())).thenReturn(mockCredCard);
		when(creditAuthorizer.authorize(any(), anyDouble())).thenReturn(true);
		
		when(mockCredCard.getVendor()).thenReturn(cardType.getVendor());
		when(mockCredCard.getNumber()).thenReturn(number);
		
		checkoutCtl.creditDetailsEntered(cardType, number, ccv);
		
		verify(mockHotel).checkout(roomId);
		verify(checkoutUI).displayMessage(anyString());
		verify(checkoutUI).setState(CheckoutUI.State.COMPLETED);
		assertTrue(checkoutCtl.state == CheckoutCTL.State.COMPLETED);
		
	}
}
