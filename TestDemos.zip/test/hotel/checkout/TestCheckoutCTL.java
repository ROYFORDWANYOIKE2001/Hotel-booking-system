/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.checkout;

import hotel.checkout.CheckoutCTL;
import hotel.credit.CreditCard;
import hotel.credit.CreditCardType;
import hotel.entities.Hotel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.function.Executable;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class) 
public class TestCheckoutCTL {
    
    
//    CreditCardType type, int number, int ccv
    
    @Mock CreditCard mockingCreditCard;
    int number = 1;
    int ccv = 0;
    
    
    
    
    
    @InjectMocks Hotel mockHotel;  // = new Hotel();
    @InjectMocks CheckoutCTL checkoutCTL = new CheckoutCTL(mockHotel);
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    @Test
    public void testCreditDetailsThrowsRuntimeException() {
        //arrange
        //checkoutCTL.testChangeState("CANCELLED");
        
        //act
        Executable e = () -> checkoutCTL.creditDetailsEntered(CreditCardType.VISA, number, ccv);
        Throwable throwRTE = assertThrows(RuntimeException.class, e);
        
        //assert
        assertEquals("CheckoutCTL: creditDetailsEntered : bad state : ROOM", throwRTE.getMessage());
        
    }
    
    
}

