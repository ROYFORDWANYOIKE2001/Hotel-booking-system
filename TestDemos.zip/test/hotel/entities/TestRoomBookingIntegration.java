package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import hotel.credit.CreditCard;

class TestRoomBookingIntegration {
	
	Booking booking;
	Room room;
	@Mock Guest guest;
	@Mock CreditCard creditCard;
	SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");

	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		Date date = format.parse("01-01-2001");
		
		room = new Room(101, RoomType.SINGLE);
		booking = new Booking(guest, room, date, 0, 0, creditCard);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCheckinRoomAvailable() {
		//arrange
		assertTrue(booking.isPending());
		assertTrue(room.isReady());
		
		//act
		booking.checkIn();
		
		//assert
		assertTrue(booking.isCheckedIn());
		assertTrue(room.isOccupied());
	}

	@Test
	void testCheckinRoomOccupied() {
		//arrange
		room.checkin();
		assertTrue(booking.isPending());
		assertTrue(room.isOccupied());
		
		//act
		Executable e = () -> booking.checkIn();
		
		//assert
		Throwable t = assertThrows(RuntimeException.class, e);
		assertEquals("Room: checkin : bad state : OCCUPIED", t.getMessage());
	}
	
	
	@Test
	void testCheckinBookingNotPending() {
		//arrange
		booking.checkIn();
		assertFalse(booking.isPending());
		assertFalse(room.isReady());
		
		//act
		Executable e = () -> booking.checkIn();
		
		//assert
		Throwable t = assertThrows(RuntimeException.class, e);
		assertEquals("Booking: checkIn : bad state : CHECKED_IN", t.getMessage());
	}
	
	

}
