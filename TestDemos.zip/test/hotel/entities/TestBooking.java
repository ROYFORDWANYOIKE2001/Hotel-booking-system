package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.InjectMocks;

import java.util.Date;
import hotel.credit.CreditCard;
import hotel.entities.Booking;
import hotel.entities.Guest;
import hotel.entities.Room;
import hotel.entities.Service;
import hotel.entities.helpers.ServiceHelper;

import java.util.ArrayList;

@ExtendWith(MockitoExtension.class)
class TestBooking {
	
	@Mock Guest guest;
	@Mock Date bookedArrival;
	@Mock Room room;
	@Mock CreditCard creditCard;
	@Mock ServiceHelper serviceChargeHelper;
	@Mock ArrayList<Service> charges;
	//Booking booking;
	
	int stayLength = 1;
	int numberOfOccupants = 1;
	
	@InjectMocks Booking booking = new Booking(guest, room, bookedArrival, stayLength, numberOfOccupants, creditCard);
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCheckinWhenPending() {
		//arrange
		//act
		booking.checkIn();
		//assert
		verify(room).checkin();
		assertTrue(booking.isCheckedIn());
	}
	
	

}
