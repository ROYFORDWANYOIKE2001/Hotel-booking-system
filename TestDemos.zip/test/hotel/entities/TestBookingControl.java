package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import hotel.HotelHelper;
import hotel.booking.BookingCTL;
import hotel.credit.CreditCardType;

class TestBookingControl {
	
	BookingCTL control;
	Hotel hotel; 
	SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
	Date date;

	@BeforeEach
	void setUp() throws Exception {
		hotel = HotelHelper.loadHotel();
		control = new BookingCTL(hotel);
		date = format.parse("01-01-2001");
		
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testMakeBookingHappyDayScenario() {
		//arrange
		//act
		control.phoneNumberEntered(1);
		control.guestDetailsEntered("a", "b");
		control.roomTypeAndOccupantsEntered(RoomType.SINGLE, 1);
		control.bookingTimesEntered(date, 1);
		control.creditDetailsEntered(CreditCardType.VISA, 1, 1);
		//assert
		assertEquals(2,hotel.bookingsByConfirmationNumber.size());		
	}

	@Test
	void testMakeBookingCreditInvalid() {
		//arrange
		//act
		control.phoneNumberEntered(1);
		control.guestDetailsEntered("a", "b");
		control.roomTypeAndOccupantsEntered(RoomType.SINGLE, 1);
		control.bookingTimesEntered(date, 1);
		control.creditDetailsEntered(CreditCardType.VISA, 7, 1);
		//assert
		assertEquals(1,hotel.bookingsByConfirmationNumber.size());		
	}

}
