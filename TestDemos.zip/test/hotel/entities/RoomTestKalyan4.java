/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.entities;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Spy;

import hotel.credit.CreditCard;
import hotel.entities.helpers.BookingHelper;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
/**
 *
 * @author Kalyan
 */

@RunWith(MockitoJUnitRunner.class)
public class RoomTestKalyan4 {
    
    int roomId = 1;
    int stayLength = 1;
    int numberOfOccupants = 1;
    RoomType roomType = RoomType.SINGLE;
    
    @Mock Date arrivalDate;
    @Mock Booking booking;
    @Mock Guest guest;
    @Mock CreditCard creditCard;
    
    @Mock BookingHelper bookingHelper;
    @Spy List<Booking> bookings = new ArrayList<>();
    
    @Rule public ExpectedException exception = ExpectedException.none();
    
    @InjectMocks Room room = new Room(roomId, roomType);

    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testBook() {
        //arrange
        when(bookingHelper.makeBooking(any(Guest.class), any(Room.class), any(Date.class), anyInt(), anyInt(), any(CreditCard.class))).thenReturn(booking);
        //act
        Booking actual = room.book(guest, arrivalDate, stayLength, numberOfOccupants, creditCard);
        //assert
        assertEquals(booking, actual);
        verify(bookings).add(booking);
    }
    

    @Test
    public void testCheckinWhenNotReady() {
        //arrange
        assertTrue(room.isReady());
        exception.expect(RuntimeException.class);
        exception.expectMessage("Cannot checkin to a room that is not in READY state");
        room.checkin();
        
        //act
        room.checkin();

        //assert
        fail("Should have thrown a RuntimeException");
    }

    
    @Test
    public void testCheckinWhenReady() {
        //arrange
        assertTrue(room.isReady());
        //act
        room.checkin();
        //assert
        assertTrue(room.isOccupied());
    }
    
    
    @Test
    public void testCheckoutWhenNotOccupied() {
        //arrange
        assertFalse(room.isOccupied());
        exception.expect(RuntimeException.class);
        exception.expectMessage("Cannot checkout of room that is not in OCCUPIED state");
        
        //act
        room.checkout(booking);
        
        //assert
        fail("Should have thrown a RuntimeException");
    }
    
    
    @Test
    public void testCheckoutWhenOccupied() {
        //arrange
        bookings.add(booking);
        room.checkin();
        assertTrue(room.isOccupied());
        //act
        room.checkout(booking);
        //assert
        assertTrue(room.isReady());
        verify(bookings).remove(booking);
    }
}