package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import hotel.credit.CreditCard;
import hotel.entities.helpers.BookingHelper;


@ExtendWith(MockitoExtension.class)
class TestRoom {

	@Mock BookingHelper bookingHelper;
	@Spy List<Booking> bookings = new ArrayList<>();
	@Mock Guest guest;	
	@Mock Date date;	
	@Mock CreditCard creditCard;	
	@Mock Booking booking;

	@InjectMocks Room room = new Room(101, RoomType.SINGLE);
	

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testBookNoConflicts() {
		
		bookings.add(booking);
		
		when(bookingHelper.makeBooking(any(Guest.class), any(Room.class), any(Date.class), anyInt(), anyInt(), any(CreditCard.class))).thenReturn(booking);
		when(booking.doTimesConflict(any(Date.class), anyInt())).thenReturn(false);
		
		Booking actual = room.book(guest, date, 1, 1, creditCard);

		assertNotNull(actual);
		verify(booking).doTimesConflict(any(Date.class), anyInt());
		verify(bookingHelper).makeBooking(any(Guest.class), any(Room.class), any(Date.class), anyInt(), anyInt(), any(CreditCard.class));
		assertEquals(2, bookings.size());		
	}
	
	
	@Test
	void testBookTimesConflicts() {
		
		bookings.add(booking);
		
		when(booking.doTimesConflict(any(Date.class), anyInt())).thenReturn(true);
		
		Executable e = () -> room.book(guest, date, 1, 1, creditCard);
		
		assertThrows(RuntimeException.class,e);
		verify(booking).doTimesConflict(any(Date.class), anyInt());
		assertEquals(1, bookings.size());
	}

	
	

}
