package hotel.entities;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.junit.platform.runner.JUnitPlatform;

import hotel.credit.CreditCard;
import hotel.entities.helpers.BookingHelper;


@RunWith(JUnitPlatform.class)
public class TestRoom4 {
	
	@Mock BookingHelper bookingHelper;
	@Spy List<Booking> bookings = new ArrayList<>();
	@Mock Guest guest;	
	@Mock Date date;	
	@Mock CreditCard creditCard;	
	@Mock Booking booking;

	@InjectMocks Room room = new Room(101, RoomType.SINGLE);

	@Rule ExpectedException exception = ExpectedException.none();

	
	
	@Test
	void testBookTimesConflicts() {
		//arrange
		bookings.add(booking);		
		when(booking.doTimesConflict(any(Date.class), anyInt())).thenReturn(true);
		exception.expect(RuntimeException.class);
		exception.expectMessage("Cannot create an overlapping booking");
		
		//act
		room.book(guest, date, 1, 1, creditCard);
		
	}

}
