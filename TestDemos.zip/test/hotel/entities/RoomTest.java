/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import hotel.credit.CreditCard;
import hotel.entities.helpers.BookingHelper;
/**
 *
 * @author Kalyan
 */
@ExtendWith(MockitoExtension.class)
public class RoomTest {
    
    int roomId = 1;
    int stayLength = 1;
    int numberOfOccupants = 1;
    RoomType roomType = RoomType.SINGLE;
    
    @Mock Date arrivalDate;// = mock(Date.class);
    @Mock Booking booking;//  = mock(Booking.class);
    @ Mock Guest guest;//  = mock(Guest.class);
    @Mock CreditCard creditCard;//  = mock(CreditCard.class);
    
//    @Mock BookingHelper bookingHelper = mock(BookingHelper.class);
//    @Spy ArrayList<Booking> bookings = mock(ArrayList.class);
    
    @Mock BookingHelper helper;
    @Spy List<Booking> bookings = new ArrayList<>();
    
    @InjectMocks Room room = new Room(roomId, roomType);

    
    
    
	@BeforeAll
    public static void setUpClass() {
    }
    
	@AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    

    
    @Test
    public void testBook() {
        //arrange
        when(helper.makeBooking(any(Guest.class), any(Room.class), any(Date.class), anyInt(), anyInt(), any(CreditCard.class))).thenReturn(booking);
        //act
        Booking actual = room.book(guest, arrivalDate, stayLength, numberOfOccupants, creditCard);
        //assert
        assertEquals(booking, actual);
        verify(bookings).add(booking);
    }
    
    

    @Test
    public void testCheckinWhenNotReady() {
        //arrange
        assertTrue(room.isReady());
        room.checkin();
        //act
        Executable e = () -> room.checkin();
        Throwable t = assertThrows(RuntimeException.class, e);
        //assert
        assertTrue(t.getMessage().contains("Room: checkin : bad state : OCCUPIED"));
        //assertEquals("Cannot checkin to a room that is not in READY state", t.getMessage());
    }

@Test
    public void testCheckinWhenReady() {
        //arrange
        assertTrue(room.isReady());
        //act
        room.checkin();
        //assert
        assertTrue(room.isOccupied());
    }
    /**
     * Test of checkout method, of class Room.
     */
    @Test
    public void testCheckoutWhenNotOccupied() {
        //arrange
        assertFalse(room.isOccupied());
        //act
        Executable e = () -> room.checkout(booking);
        Throwable t = assertThrows(RuntimeException.class, e);
        //assert
        assertTrue(t.getMessage().contains("Room: checkout : bad state : READY"));
        //assertEquals("Cannot checkout of room that is not in OCCUPIED state",t.getMessage());
    }
    
    @Test
    public void testCheckoutWhenOccupied() {
        //arrange
        bookings.add(booking);
        room.checkin();
        assertTrue(room.isOccupied());
        //act
        room.checkout(booking);
        //assert
        assertTrue(room.isReady());
        verify(bookings).remove(booking);
    }
}