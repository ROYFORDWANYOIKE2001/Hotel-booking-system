package hotel.entities;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import hotel.credit.CreditCard;

@ExtendWith(MockitoExtension.class)
class TestHotel {
	
	@Mock Room mockRoom;
	@Mock Guest mockGuest;
	Date arrivalDate;
	int stayLength;
	int occupantNumber;
	@Mock CreditCard mockCard;
	@Spy Map<Long, Booking> bookingsByConfirmationNumber = new HashMap<Long, Booking>();
	SimpleDateFormat format;
	
	@Mock Booking mockBooking;
	long confirmationNumber;

	@InjectMocks Hotel hotel;

	
	
	@BeforeEach
	void setUp() throws Exception {
		format = new SimpleDateFormat("dd-MM-yyyy");
		arrivalDate = format.parse("11-12-2001");
		stayLength = 1;
		occupantNumber = 1;
		confirmationNumber = 11122001101L;
	}

	
	@AfterEach
	void tearDown() throws Exception {
	}

	
	@Test
	void testBookAllValid() {
		//arrange
		//when(mockRoom.book(mockGuest, arrivalDate, stayLength, occupantNumber, mockCard)).thenReturn(mockBooking);
		when(mockRoom.book(mockGuest, arrivalDate, stayLength, occupantNumber, mockCard)).thenAnswer(new Answer<Object>() {
		
			@Override
			public Object answer(InvocationOnMock arg0) throws Throwable {				
				return mockBooking;			
			}
			
		});
		when(mockBooking.getConfirmationNumber()).thenReturn(confirmationNumber);
		assertEquals(0, bookingsByConfirmationNumber.size());

		//act
		long actual = hotel.book(mockRoom, mockGuest, arrivalDate, stayLength, occupantNumber, mockCard);
		
		//assert
		verify(mockRoom).book(mockGuest, arrivalDate, stayLength, occupantNumber, mockCard);
		assertEquals(confirmationNumber, actual);
		assertEquals(1, bookingsByConfirmationNumber.size());
		assertEquals(mockBooking, hotel.findBookingByConfirmationNumber(actual));
	}
	

	@Test
	void testBookRoomThrowsException() {
		//arrange
		when(mockRoom.book(mockGuest, arrivalDate, stayLength, occupantNumber, mockCard))
			.thenThrow(new RuntimeException("Error message"));
		assertEquals(0, bookingsByConfirmationNumber.size());

		//act
		Executable e = () -> hotel.book(mockRoom, mockGuest, arrivalDate, stayLength, occupantNumber, mockCard);
		Throwable t = assertThrows(RuntimeException.class, e);
		
		//assert
		verify(mockRoom).book(mockGuest, arrivalDate, stayLength, occupantNumber, mockCard);
		assertEquals(0, bookingsByConfirmationNumber.size());
		assertEquals("Error message", t.getMessage());
	}
	
}
