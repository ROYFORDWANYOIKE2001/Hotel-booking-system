package hotel.booking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
//import static org.mockito.ArgumentMatchers.any;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import hotel.booking.BookingCTL;
import hotel.booking.BookingUI;
import hotel.booking.BookingCTL.State;
import hotel.credit.CreditAuthorizer;
import hotel.credit.CreditCard;
import hotel.credit.CreditCardHelper;
import hotel.credit.CreditCardType;
import hotel.entities.Guest;
import hotel.entities.Hotel;
import hotel.entities.Room;
import hotel.entities.RoomType;

class TestBookingCTL {
	
	@Mock BookingUI bookingUI;
	@Mock Hotel hotel;
	@Mock CreditAuthorizer authorizer;
	@Mock CreditCardHelper creditCardHelper;

	@Mock Guest guest;
	@Mock Room room;
	@Mock CreditCard creditCard;
	private double cost;
	
	State state;
	int phoneNumber;
	RoomType selectedRoomType;
	int occupantNumber;
	Date arrivalDate;
	int stayLength;
	int cardNum;
	int ccv;
	CreditCardType cardType;
	long confNum;
	
	static SimpleDateFormat format;
	
	BookingCTL control;

	
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		format = new SimpleDateFormat("dd-MM-yyyy");
	}

	
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		control = new BookingCTL(hotel);
		control.bookingUI = bookingUI;
		control.creditAuthorizer = authorizer;
		control.creditCardHelper = creditCardHelper;
		
		arrivalDate = format.parse("11-11-2011");
		stayLength = 1;
		occupantNumber = 1;
		cardNum = 1;
		ccv = 1;
		cardType = CreditCardType.VISA;
		cost = 111.11;
		confNum = 11112001101L;
	}

	
	@AfterEach
	void tearDown() throws Exception {
	}

	
	@Test
	void testPhoneNumberEnteredGuestExists() {
		//arrange
		assertTrue(control.state == State.PHONE);
		when(hotel.isRegistered(anyInt())).thenReturn(true);
		when(hotel.findGuestByPhoneNumber(anyInt())).thenReturn(guest);
		when(guest.getName()).thenReturn("A");
		when(guest.getAddress()).thenReturn("Z");
		when(guest.getPhoneNumber()).thenReturn(1);
		
		ArgumentCaptor<String> nameCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> addressCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<Integer> phoneCaptor = ArgumentCaptor.forClass(Integer.class);
		ArgumentCaptor<BookingUI.State> uiStateCaptor = ArgumentCaptor.forClass(BookingUI.State.class);
			
		//act
		control.phoneNumberEntered(1);
		
		//assert
		verify(hotel).isRegistered(anyInt());
		verify(hotel).findGuestByPhoneNumber(anyInt());
		verify(bookingUI).displayGuestDetails(nameCaptor.capture(), addressCaptor.capture(), phoneCaptor.capture());
		verify(bookingUI).setState(uiStateCaptor.capture());
		
		assertEquals("A", nameCaptor.getValue());
		assertEquals("Z", addressCaptor.getValue());
		assertTrue(1 == phoneCaptor.getValue());
		assertTrue(BookingUI.State.ROOM == uiStateCaptor.getValue());
		assertTrue(State.ROOM == control.state);
	}
	
	

	@Test
	void testCreditDetailsEnteredCreditApproved() {
		//arrange
		control.state = State.CREDIT; 
		control.guest = guest;
		control.room = room;
		control.cost = cost;
		control.arrivalDate = arrivalDate;
		control.stayLength = stayLength;
		control.occupantNumber = occupantNumber;
		
		ArgumentCaptor<String> descCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<Integer> numCaptor = ArgumentCaptor.forClass(Integer.class);
		ArgumentCaptor<Date> dateCaptor = ArgumentCaptor.forClass(Date.class);
		ArgumentCaptor<Integer> stayCaptor = ArgumentCaptor.forClass(Integer.class);
		ArgumentCaptor<String> nameCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<String> vendorCaptor = ArgumentCaptor.forClass(String.class);
		ArgumentCaptor<Integer> cardNumCaptor = ArgumentCaptor.forClass(Integer.class);
		ArgumentCaptor<Double> costCaptor = ArgumentCaptor.forClass(Double.class);
		ArgumentCaptor<Long> confNumCaptor = ArgumentCaptor.forClass(Long.class);		
		ArgumentCaptor<BookingUI.State> uiStateCaptor = ArgumentCaptor.forClass(BookingUI.State.class);
		
		when(creditCardHelper.makeCreditCard(any(), anyInt(), anyInt())).thenReturn(creditCard);
		when(authorizer.authorize(any(), anyDouble())).thenReturn(true);

		when(hotel.book(room, guest, arrivalDate, stayLength, occupantNumber, creditCard))
			.thenReturn(confNum);

		when(room.getDescription()).thenReturn("Description");
		when(room.getId()).thenReturn(101);
		when(guest.getName()).thenReturn("A");
		when(creditCard.getVendor()).thenReturn(cardType.getVendor());
		when(creditCard.getNumber()).thenReturn(cardNum);

		assertTrue(control.state == State.CREDIT);
		
		//act
		control.creditDetailsEntered(CreditCardType.VISA, 1, 1);
		
		//assert
		verify(creditCardHelper).makeCreditCard(any(),anyInt(), anyInt());
		verify(authorizer).authorize(creditCard, cost);
		
		verify(hotel).book(room, guest, 
				arrivalDate, stayLength, 
				occupantNumber, creditCard);
		
		verify(bookingUI).displayConfirmedBooking(
				descCaptor.capture(), numCaptor.capture(), 
				dateCaptor.capture(), stayCaptor.capture(), nameCaptor.capture(),
				vendorCaptor.capture(), cardNumCaptor.capture(), costCaptor.capture(),
				confNumCaptor.capture());

		verify(bookingUI).setState(uiStateCaptor.capture());
		
		assertEquals("Description", descCaptor.getValue());
		assertTrue(101 == numCaptor.getValue());
		assertEquals(arrivalDate, dateCaptor.getValue());
		assertTrue(1 == stayCaptor.getValue());
		assertEquals("A", nameCaptor.getValue());
		assertEquals("Visa", vendorCaptor.getValue());
		assertTrue(1 == cardNumCaptor.getValue());
		assertEquals(cost, costCaptor.getValue(), 0.001);
		assertTrue(confNum == confNumCaptor.getValue());
		
		assertTrue(BookingUI.State.COMPLETED == uiStateCaptor.getValue());
		assertTrue(State.COMPLETED == control.state);		
	}
	

	@Test
	void testCreditDetailsEnteredCreditNotApproved() {
		//arrange
		control.state = State.CREDIT; 
		control.guest = guest;
		control.room = room;
		control.cost = cost;
		control.arrivalDate = arrivalDate;
		control.stayLength = stayLength;
		control.occupantNumber = occupantNumber;
		
		ArgumentCaptor<String> mesgCaptor = ArgumentCaptor.forClass(String.class);
		
		String expectedMessage = String.format(
				"\n%s credit card number %d was not authorized for $%.2f\n",
				cardType.getVendor(), cardNum, cost);
		
		when(creditCardHelper.makeCreditCard(any(),anyInt(), anyInt())).thenReturn(creditCard);
		when(authorizer.authorize(any(), anyDouble())).thenReturn(false);

		when(creditCard.getVendor()).thenReturn(cardType.getVendor());
		when(creditCard.getNumber()).thenReturn(cardNum);

		assertTrue(control.state == State.CREDIT);
		
		//act
		control.creditDetailsEntered(cardType, cardNum, ccv);
		
		//assert
		verify(creditCardHelper).makeCreditCard(any(),anyInt(), anyInt());
		verify(authorizer).authorize(creditCard, cost);
		
		verify(bookingUI).displayMessage(mesgCaptor.capture());
		
		assertEquals(expectedMessage, mesgCaptor.getValue());

		assertTrue(State.CREDIT == control.state);		
	}
	

	@Test
	void testCreditDetailsEnteredControlNotInCREDITState() {
		//arrange
		control.state = State.TIMES; 
		control.guest = guest;
		control.room = room;
		control.cost = cost;
		control.arrivalDate = arrivalDate;
		control.stayLength = stayLength;
		control.occupantNumber = occupantNumber;
		
		String expectedMessage = String.format("BookingCTL: bookingTimesEntered : bad state : %s", State.TIMES);
		
		assertTrue(control.state != State.CREDIT);
		
		//act
		Executable e = () -> control.creditDetailsEntered(CreditCardType.VISA, 1, 1);
		
		//assert
		Throwable t = assertThrows(RuntimeException.class, e);
		assertEquals(expectedMessage, t.getMessage());

		assertTrue(State.TIMES == control.state);		
	}
	

}
