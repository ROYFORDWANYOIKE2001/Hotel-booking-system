package hotel.checkout;

import java.text.SimpleDateFormat;
import java.util.List;

import hotel.credit.CreditAuthorizer;
import hotel.credit.CreditCard;
import hotel.credit.CreditCardHelper;
import hotel.credit.CreditCardType;
import hotel.entities.Booking;
import hotel.entities.Guest;
import hotel.entities.Hotel;
import hotel.entities.Service;
import hotel.utils.IOUtils;

public class CheckoutCTL {

	enum State {ROOM, ACCEPT, CREDIT, CANCELLED, COMPLETED };
	
	Hotel hotel;
	State state;
	CheckoutUI checkoutUI;
	CreditCardHelper creditCardHelper;
	CreditAuthorizer creditAuthorizer;
	double total;
	int roomId;


	public CheckoutCTL(Hotel hotel) {
		this.hotel = hotel;
		this.checkoutUI = new CheckoutUI(this);
		this.creditCardHelper = CreditCardHelper.getInstance();
		this.creditAuthorizer = CreditAuthorizer.getInstance();
		state = State.ROOM;
	}

	
	public void run() {
		IOUtils.trace("BookingCTL: run");
		checkoutUI.run();
	}

	
	public void roomIdEntered(int roomId) {
		if (state != State.ROOM) {
			String mesg = String.format("CheckoutCTL: roomIdEntered : bad state : %s", state);
			throw new RuntimeException(mesg);
		}
		this.roomId = roomId;
		Booking booking = hotel.findActiveBookingByRoomId(roomId);
		if (booking == null) {
			String mesg = String.format("No active booking found for room id %d", roomId);			
			checkoutUI.displayMessage(mesg);
			//cancel();
		}	
		else {			
			StringBuilder sb = new StringBuilder();
			sb.append(String.format("Charges for room: %d, booking: %d\n", 
					roomId, booking.getConfirmationNumber()));
			
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			String dateStr = format.format(booking.getArrivalDate());
			sb.append(String.format("Arrival date: %s, Staylength: %d\n", dateStr, booking.getStayLength()));
			
			Guest guest = booking.getGuest();
			sb.append(String.format("Guest: %s, Address: %s, Phone: %d\n", 
					guest.getName(), guest.getAddress(), guest.getPhoneNumber()));
			
			sb.append("Charges:\n");
			
			total = 0;
			List<Service> charges = booking.getCharges();
			for (Service sc : charges) {
				total += sc.getCost();
				String chargeStr = String.format("    %-12s:%10s", 
						sc.getDescription(), String.format("$%.2f", sc.getCost()));
				sb.append(chargeStr).append("\n");			
			}
			sb.append(String.format("Total: $%.2f\n", total));
			String mesg = sb.toString();
			checkoutUI.displayMessage(mesg);
			state = State.ACCEPT;
			checkoutUI.setState(CheckoutUI.State.ACCEPT);	
		}
	}


	public void chargesAccepted(boolean accepted) {
		if (state != State.ACCEPT) {
			String mesg = String.format("CheckoutCTL: roomIdEntered : bad state : %s", state);
			throw new RuntimeException(mesg);
		}
		if (!accepted) {
			checkoutUI.displayMessage("Charges not accepted");
			cancel();
		}
		else {
			checkoutUI.displayMessage("Charges accepted");
			state = State.CREDIT;
			checkoutUI.setState(CheckoutUI.State.CREDIT);
		}		
	}

	
	public void creditDetailsEntered(CreditCardType type, int number, int ccv) {
		if (state != State.CREDIT) {
			String mesg = String.format("CheckoutCTL: creditDetailsEntered : bad state : %s", state);
			throw new RuntimeException(mesg);
		}
		CreditCard card = creditCardHelper.makeCreditCard(type, number, ccv);
		boolean approved = creditAuthorizer.authorize(card, total);
		if (!approved) {
			String outputStr = String.format(
					"%s credit card number %d was not authorized for $%.2f",
					type.getVendor(), number, total);
					
			checkoutUI.displayMessage(outputStr);
			//cancel();
		}
		else {
			hotel.checkout(roomId);
			String outputStr = String.format(
					"%s credit card number %d was debited $%.2f",
					card.getVendor(), card.getNumber(), total);
			checkoutUI.displayMessage(outputStr);
			state = State.COMPLETED;
			checkoutUI.setState(CheckoutUI.State.COMPLETED);
		}
	}


	public void cancel() {
		checkoutUI.displayMessage("Checking out cancelled");
		state = State.CANCELLED;
		checkoutUI.setState(CheckoutUI.State.CANCELLED);
	}
	
	
	public void completed() {
		checkoutUI.displayMessage("Checking out completed");
	}



}
