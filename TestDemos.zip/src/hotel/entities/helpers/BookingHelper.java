package hotel.entities.helpers;

import java.util.Date;

import hotel.credit.CreditCard;
import hotel.entities.Booking;
import hotel.entities.Guest;
import hotel.entities.Room;

public class BookingHelper {
	
	private static BookingHelper self;

	
	public static BookingHelper getInstance() {
		if (self == null) {
			self = new BookingHelper();
		}
		return self;
	}
	
	
	private BookingHelper() {}

	
	
	public Booking makeBooking(Guest guest, Room room, Date arrivalDate, 
			int stayLength, int numberOfOccupants, 
			CreditCard creditCard) {
		
		return new Booking(guest, room, arrivalDate, stayLength, numberOfOccupants, creditCard);
	}

}
