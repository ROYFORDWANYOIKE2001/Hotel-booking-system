package hotel.entities.helpers;

import hotel.entities.Service;
import hotel.entities.ServiceType;

public class ServiceHelper {

	private static ServiceHelper self;

	public static ServiceHelper getInstance() {
		if (self == null) {
			self = new ServiceHelper();
		}
		return self;
	}


	public Service makeService(ServiceType serviceType, double cost) {
		return new Service(serviceType, cost);
	}

}
