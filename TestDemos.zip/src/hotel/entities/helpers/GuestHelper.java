package hotel.entities.helpers;

import hotel.entities.Guest;

public class GuestHelper {
	
	static GuestHelper self;

	public static GuestHelper getInstance() {
		if (self == null) {
			self = new GuestHelper();
		}
		return self;
	}


	public Guest makeGuest(String name, String address, int phoneNumber) {
		return new Guest(name, address, phoneNumber);
	}

}
