package hotel.entities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import hotel.credit.CreditCard;
import hotel.entities.helpers.ServiceHelper;
import hotel.utils.IOUtils;

public class Booking {
	
	enum State {PENDING, CHECKED_IN, CHECKED_OUT};
	
	Guest guest;
	Room room;
	Date bookedArrival; 
	int stayLength;
	int numberOfOccupants;
	CreditCard creditCard;
	
	ServiceHelper serviceChargeHelper;	
	List<Service> charges;
	
	State state;


	// for testing
	public Booking(int stayLength, int numberOfOccupants) {
		this.stayLength = stayLength;
		this.numberOfOccupants = numberOfOccupants;
		this.serviceChargeHelper = ServiceHelper.getInstance();		
		this.state = State.PENDING;
	}

	
	public Booking(Guest guest, Room room, 
			Date arrivalDate, int stayLength, 
			int numberOfOccupants, 
			CreditCard creditCard) {
		this(stayLength, numberOfOccupants);
		this.guest = guest;
		this.room = room;
		this.bookedArrival = arrivalDate;
		this.creditCard = creditCard;
		this.serviceChargeHelper = ServiceHelper.getInstance();
		this.charges = new ArrayList<>();
	}

	
	private long generateConfirmationNumber(int roomId, Date arrivalDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(arrivalDate);
		
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		
		String numberString = String.format("%d%d%d%d", day, month, year, roomId);
		
		return Long.parseLong(numberString);
	}


	public boolean doTimesConflict(Date requestedArrival, int stayLength) {
		IOUtils.trace("Booking: timesConflict");

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(bookedArrival);
		calendar.add(Calendar.DATE, stayLength);
		Date bookedDeparture = calendar.getTime();
		
		calendar.setTime(requestedArrival);
		calendar.add(Calendar.DATE, stayLength);
		Date requestedDeparture = calendar.getTime();
		
		boolean doesConflict = requestedArrival.before(bookedDeparture) && 
				requestedDeparture.after(bookedArrival);

		return doesConflict;
	}


	public long getConfirmationNumber() {
		int roomId = room.getId();
		long confNum = generateConfirmationNumber(roomId, bookedArrival);
		return confNum;
	}


	public int getRoomId() {
		return room.getId();
	}
	
	
	public Room getRoom() {
		return room;
	}


	public Date getArrivalDate() {
		return bookedArrival;
	}


	public int getStayLength() {
		return stayLength;
	}


	public Guest getGuest() {
		return guest;
	}


	public CreditCard getCreditCard() {
		return creditCard;
	}


	public boolean isPending() {
		return state == State.PENDING;
	}


	public boolean isCheckedIn() {
		return state == State.CHECKED_IN;
	}


	public boolean isCheckedOut() {
		return state == State.CHECKED_OUT;
	}


	public List<Service> getCharges() {
		return Collections.unmodifiableList(charges);
	}


	public void checkIn() {
		if (state != State.PENDING) {
			String mesg = String.format("Booking: checkIn : bad state : %s", state);
			throw new RuntimeException(mesg);
		}	
		room.checkin();
		state = State.CHECKED_IN;
	}


	public void checkOut() {
		if (state != State.CHECKED_IN) {
			String mesg = String.format("Booking: checkOut : bad state : %s", state);
			throw new RuntimeException(mesg);
		}	
		room.checkout(this);
		state = State.CHECKED_OUT;
	}


	public void addServiceCharge(ServiceType serviceType, double cost) {
		if (state != State.CHECKED_IN) {
			String mesg = String.format("Booking: addServiceCharge : bad state : %s", state);
			throw new RuntimeException(mesg);
		}	
		Service charge = serviceChargeHelper.makeService(serviceType, cost);
		charges.add(charge);
	}


}
